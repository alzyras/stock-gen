import logging
import os
from dataclasses import dataclass
from typing import Literal

import pandas as pd
from sqlalchemy import create_engine

LOGGER = logging.getLogger(__name__)


@dataclass
class DatabricksConfig:
    """Dataclass to store Databricks configuration."""

    token: str
    server_hostname: str
    http_path: str
    catalog: str
    schema: str

    def to_url(self) -> str:
        """Convert Databricks configuration to URL."""
        return (
            f"databricks://token:{self.token}@"
            f"{self.server_hostname}?"
            f"http_path={self.http_path}&"
            f"catalog={self.catalog}&"
            f"schema={self.schema}"
        )


DEFAULT_DATABRICKS_CONFIG = DatabricksConfig(
    token=os.environ["DATABRICKS_TOKEN"],
    server_hostname=os.environ["DATABRICKS_HOSTNAME"],
    http_path=os.environ["DATABRICKS_HTTP_PATH"],
    catalog=os.environ["DATABRICKS_CATALOG"],
    schema=os.environ["DATABRICKS_SCHEMA"],
)


def fetch_databricks_data(
    query: str,
    db_config: DatabricksConfig = DEFAULT_DATABRICKS_CONFIG,
) -> pd.DataFrame:
    """Fetch data from Databricks using the given query.

    Args:
        query (str): Query to fetch data
        db_config (DatabricksConfig): Configuration for Databricks connection

    Returns:
        pd.DataFrame: Data fetched from Databricks

    """
    engine = create_engine(url=db_config.to_url())
    with engine.connect() as connection:
        data = pd.read_sql(query, connection)
    engine.dispose()
    LOGGER.info(f"Fetched data with shape: {data.shape}")
    return data


def upload_databricks_data(
    data: pd.DataFrame,
    table_name: str,
    write_preference: Literal["fail", "replace", "append"],
    db_config: DatabricksConfig = DEFAULT_DATABRICKS_CONFIG,
) -> None:
    """Upload data to Databricks.

    Args:
        data (pd.DataFrame): Data to upload
        table_name (str): Name of the table to upload
        write_preference (Literal["fail", "replace", "append"]): What to do if the table already exists
        db_config (DatabricksConfig): Configuration for Databricks connection

    """
    engine = create_engine(url=db_config.to_url())
    with engine.connect() as connection:
        data.to_sql(
            table_name,
            connection,
            if_exists=write_preference,
            index=False,
            method="multi",
            chunksize=100,
        )
    engine.dispose()
