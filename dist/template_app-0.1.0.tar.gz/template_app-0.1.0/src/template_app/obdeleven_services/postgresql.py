import os
from dataclasses import dataclass
from typing import Literal

import pandas as pd
import psycopg2


@dataclass
class PostgresConfig:
    """Dataclass to store PostgreSQL configuration."""

    host: str
    name: str
    user: str
    password: str
    port: str


DEFAULT_POSTGRES_CONFIG = PostgresConfig(
    user=os.environ["POSTGRES_USER"],
    password=os.environ["POSTGRES_PASSWORD"],
    host=os.environ["POSTGRES_HOST"],
    name=os.environ["POSTGRES_DB"],
    port=os.environ["POSTGRES_PORT"],
)


def get_pg_connection(db_config: PostgresConfig) -> psycopg2.extensions.connection:
    """Create a connection to the PostgreSQL database.

    Args:
        db_config (PostgresConfig): The database configuration

    Returns:
        psycopg2.extensions.connection: The connection to the database

    """
    return psycopg2.connect(
        host=db_config.host,
        dbname=db_config.name,
        user=db_config.user,
        password=db_config.password,
        port=db_config.port,
    )


def upload_data_to_pg(
    data: pd.DataFrame,
    table_name: str,
    write_preference: Literal["fail", "replace", "append"],
    db_config: PostgresConfig = DEFAULT_POSTGRES_CONFIG,
) -> None:
    """Upload data to a PostgreSQL database.

    Args:
        data (pd.DataFrame): Data to upload
        table_name (str): Name of the table to upload
        write_preference (Literal["fail", "replace", "append"]): What to do if the table already exists
        db_config (PostgresConfig): The database configuration

    """
    with get_pg_connection(db_config) as connection:
        cursor = connection.cursor()
        data.to_sql(table_name, cursor, if_exists=write_preference)
        connection.commit()


def fetch_data_from_pg(
    query: str,
    db_config: PostgresConfig = DEFAULT_POSTGRES_CONFIG,
) -> pd.DataFrame:
    """Fetch data from a PostgreSQL database.

    Args:
        query (str): Query to fetch data
        db_config (PostgresConfig): The database configuration

    Returns:
        pd.DataFrame: Data fetched from the database

    """
    with get_pg_connection(db_config) as connection:
        return pd.read_sql(query, connection)
