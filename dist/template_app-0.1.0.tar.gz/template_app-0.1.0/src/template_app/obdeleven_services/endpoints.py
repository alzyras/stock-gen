import os
from typing import Literal

import requests

EMBEDDING_SERVICE_URL = os.environ["EMBEDDING_SERVICE_URL"]
SCRAPING_SERVICE_URL = os.environ["SCRAPING_SERVICE_URL"]
SEARCH_SERVICE_URL = os.environ["SEARCH_SERVICE_URL"]
TIMEOUT = 30


def embed_text(
    text: str,
    text_type: Literal["query", "document"] = "document",
    embedding_service_url: str = EMBEDDING_SERVICE_URL,
) -> list[float]:
    """Embed a given text using the embedding service.

    Args:
        text (str): Text to embed
        text_type (Literal["query", "document"]): Type of the text, if text will be used as an item to be retrieved, use "document", if text will be used as a query to search for items, use "query"
        embedding_service_url (str): URL of the embedding service

    Returns:
        List[float]: Embedding of the text

    """
    body = {"text": text, "text_type": text_type}
    response = requests.post(embedding_service_url, json=body, timeout=TIMEOUT)
    return response.json()["embedding"]


def scrape_url(url: str, scraping_service_url: str = SCRAPING_SERVICE_URL) -> str:
    """Scrape the HTML content of a given URL.

    Args:
        url (str): URL to scrape
        scraping_service_url (str): URL of the scraping service

    Returns:
        str: HTML content of the URL

    """
    body = {"url": url}
    response = requests.get(scraping_service_url, json=body, timeout=TIMEOUT)
    return response.json()["html"]


def web_search(
    query: str,
    search_service_url: str = SEARCH_SERVICE_URL,
) -> list[dict[str, str]]:
    """Search the web for a given query.

    Args:
        query (str): Query to search for
        search_service_url (str): URL of the search service

    Returns:
        List[Dict[str, str]]: List of search results, each containing url, title, and description

    """
    body = {"query": query}
    response = requests.get(search_service_url, json=body, timeout=TIMEOUT)
    return response.json()
