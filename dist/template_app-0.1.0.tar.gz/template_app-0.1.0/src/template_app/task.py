import argparse
import logging

from template_app.addition import add
from template_app.obdeleven_services.databricks import (
    fetch_databricks_data,
    upload_databricks_data,
)

LOGGER = logging.getLogger(__name__)

QUERY_FAULT_DESCRIPTIONS = """
    SELECT _id, en
    FROM texttable.silver_texttable
    LIMIT 10
"""


def parse_arguments() -> argparse.Namespace:
    """Parse arguments from the command line."""
    parser = argparse.ArgumentParser(description="Your program description")
    parser.add_argument("--first_number", help="First number to add", type=float)
    parser.add_argument("--second_number", help="Second number to add", type=float)
    return parser.parse_args()


def main_task() -> None:
    """Main function to fetch data from Databricks and upload it."""
    args = parse_arguments()
    data = fetch_databricks_data(QUERY_FAULT_DESCRIPTIONS)
    upload_databricks_data(data, "text_data", "append")
    addition_result = add(args.first_number, args.second_number)
    LOGGER.info(f"Addition result: {addition_result}")


if __name__ == "__main__":
    main_task()
